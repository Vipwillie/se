CREATE TRIGGER BS_PUBMSG
  BEFORE INSERT
  ON BS_PUBMSG
  FOR EACH ROW
  DECLARE last_Sequence NUMBER; last_InsertID NUMBER;
      BEGIN
        IF (:NEW."PKID" IS NULL)
        THEN
          SELECT BS_PUBMSG_0.NEXTVAL INTO :NEW."PKID" FROM DUAL;
        ELSE
          SELECT Last_Number-1 INTO last_Sequence FROM User_Sequences WHERE UPPER(Sequence_Name) = UPPER('BS_PUBMSG_0');
          SELECT :NEW."PKID" INTO last_InsertID FROM DUAL;
          WHILE (last_InsertID > last_Sequence)
          LOOP
            SELECT BS_PUBMSG_0.NEXTVAL INTO last_Sequence FROM DUAL;
          END LOOP;
        END IF;
      END;







/

