CREATE VIEW V_BS_LOGINSESSION_COUNT AS
  select
               rq as rq,
               hydm as hydm,
               logintime as logintime,
               lasttime as lasttime,
               daycount as daycount
          from bs_loginsession_count
        union all
          select
             to_date(to_char(max(logintime),'yyyyMMdd'),'yyyyMMdd') as rq,
             hydm as hydm,
             max(logintime) as logintime,
             max(lasttime) as lasttime,
             count(*) as daycount
          from bs_loginsession where styp=1
             group by hydm,to_char(logintime,'yyyyMMdd')
        order by rq,hydm




/

