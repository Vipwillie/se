CREATE VIEW V_BS_LOGINSESSION_ALLCOUNT AS
  select
            hydm as hydm,
            max(logintime) as logintime,
            max(lasttime) as lasttime,
          sum(daycount) as allcount
        from v_bs_loginsession_count t
        group by hydm




/

