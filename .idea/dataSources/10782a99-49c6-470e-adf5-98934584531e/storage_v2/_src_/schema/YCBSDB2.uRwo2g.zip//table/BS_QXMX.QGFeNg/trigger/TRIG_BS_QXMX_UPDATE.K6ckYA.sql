CREATE TRIGGER TRIG_BS_QXMX_UPDATE
  BEFORE UPDATE
  ON BS_QXMX
  FOR EACH ROW
  declare d_sql varchar2(4000);
         olddata varchar2(4000);
begin

d_sql:='update Bs_qxmx set mkid='''||:new.mkid||''',action='''||:new.action||''',method='''||:new.method||''',accesstag='''||:new.accesstag||''',remark='''||:new.remark||''',styp='''||:new.styp||''',sid='''||:new.sid||''', where pkid = '''||:new.pkid||'''';

olddata:='update Bs_qxmx set mkid='''||:old.mkid||''',action='''||:old.action||''',method='''||:old.method||''',accesstag='''||:old.accesstag||''',remark='''||:old.remark||''',styp='''||:old.styp||''',sid='''||:old.sid||''', where pkid = '''||:old.pkid||'''';


  insert into updatesql(createtime,exesql,olddata,opertype,iden) values (sysdate,d_sql,olddata,'Update',:new.pkid);

end ;




/

