CREATE TRIGGER TRIG_BS_XTMK_DELETE
  BEFORE DELETE
  ON BS_XTMK
  FOR EACH ROW
  declare d_sql varchar2(4000);
         olddata varchar2(4000);
begin

         d_sql:='delete from Bs_Xtmk where sid ='''||:old.sid||''' and mid='''||:old.mid||'''';

         olddata := 'insert into Bs_Xtmk(mid,mname,styp,url00,url01,url02,url03,url04,url05,url06,url07,url08,url09,url10,ordby,sid,qxrole)
         values('''||:old.mid||''','''||:old.mname||''','''||:old.styp||''','''||:old.url00||''','''||:old.url01||''','''||:old.url02||''','''||:old.url03||''','''||:old.url04||''','''||:old.url05||''','''||:old.url06||''','''||:old.url07||''','''||:old.url08||''','''||:old.url09||''','''||:old.url10||''','''||:old.ordby||''','''||:old.sid||''','''||:old.qxrole||''')';

         insert into updatesql(createtime,exesql,olddata,opertype,iden) values (sysdate,d_sql,olddata,'Delete',:old.sid||'|'||:old.mid);
end ;




/

