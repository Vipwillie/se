CREATE procedure         P_VERSION(sysid varchar2,newversion varchar2,ref_msg out varchar2,opt int default 0) is
/**********************************************************
 * procedure : P_VERSION
 * dec       : 判断当前系统版本
 * author    : flotage
 * create    : 2012.12.12
 * parm     :
 *     newversion -- 当前升级文件的版本，格式必须是：大版本+小版本+子版本+升级序列,如：2.0.0.18-> 2.1.0.19
 **********************************************************/
 dbver varchar2(30);
 tmpver varchar2(30);
 newver varchar2(30);
begin
  ref_msg:='success';
  if newversion is null or nvl(ltrim(newversion),'-')='-' then
    ref_msg := '升级文件版本未知，不允许升级';
      return;
  end if;

  BEGIN
    select CURVER into dbver from SYS_SYSINFO where SYSID=sysid;
  EXCEPTION WHEN  NO_DATA_FOUND THEN
      ref_msg := '获取当前版本失败，请配置当前系统版本';
      return;
  END;

  if opt <> 0 then
    -- 更新升级文件版本
    update SYS_SYSINFO set CURVER = newversion,UPTDATE=sysdate where SYSID=sysid;
    return;
  end if;

  newver:='';
  if dbver is not null then
    if dbver=newversion then
      return;
    end if;
    -- 判断版本是否是序列，延续上一个版本
    tmpver:=dbver;
    while (instr(tmpver,'.')>0) loop
      newver := newver||substr(tmpver,1,instr(tmpver,'.'));
      tmpver := substr(tmpver,instr(tmpver,'.')+1);
    end loop;
    -- 算出DB版本中的下一个理论版本
    newver:=newver||to_char(to_number(tmpver)+1);

    if newver<>newversion then
      ref_msg := '当前升级文件版本为['||newversion||']，DB中的版本为['||dbver||']，下一版本应该为['||newver||']，升级文件版本与DB版本不匹配。';
        return;
    end if;
  end if;
end P_VERSION;





/

