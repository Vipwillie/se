CREATE TRIGGER TRIG_BS_QXMX_DELETE
  BEFORE DELETE
  ON BS_QXMX
  FOR EACH ROW
  declare d_sql varchar2(4000);
         olddata varchar2(4000);
begin

         d_sql:='delete from Bs_qxmx where pkid ='''||:old.pkid||'''';

         olddata :='insert into Bs_qxmx(pkid,mkid,action,method,accesstag,remark,styp,sid)
         values('''||:old.pkid||''','''||:old.mkid||''','''||:old.action||''','''||:old.method||''','''||:old.accesstag||''','''||:old.remark||''','''||:old.styp||''','''||:old.sid||''')';


         insert into updatesql(createtime,exesql,olddata,opertype,iden) values (sysdate,d_sql,olddata,'Delete',:old.pkid);
end ;




/

