CREATE TRIGGER TRIG_BS_SYSTEM_DELETE
  BEFORE DELETE
  ON BS_SYSTEM
  FOR EACH ROW
  declare d_sql varchar2(4000);
         olddata varchar2(4000);
begin

d_sql:='delete from bs_system where sid ='''||:old.sid||'''';

olddata := 'insert into bs_system(sid,sname,shortname,styp,homepage,orderno,url00,url01,url02,url03,url04,url05,url06,url07,url08,url09,url10,url11,url12,url13,url14,url15,url16,url17,url18,url19,url20,url21,url22,url23,url24,url25,url26,url27,url28,url29,url30)
values('''||:old.sid||''','''||:old.sname||''','''||:old.shortname||''','''||:old.styp||''','''||:old.homepage||''','''||:old.orderno||''','''||:old.url00||''','''||:old.url01||''','''||:old.url02||''','''||:old.url03||''','''||:old.url04||''','''||:old.url05||''','''||:old.url06||''','''||:old.url07||''','''||:old.url08||''','''||:old.url09||''','''||:old.url10||''','''||:old.url11||''','''||:old.url12||''','''||:old.url13||''','''||:old.url14||''','''||:old.url15||''','''||:old.url16||''','''||:old.url17||''','''||:old.url18||''','''||:old.url19||''','''||:old.url20||''','''||:old.url21||''','''||:old.url22||''','''||:old.url23||''','''||:old.url24||''','''||:old.url25||''','''||:old.url26||''','''||:old.url27||''','''||:old.url28||''','''||:old.url29||''','''||:old.url30||''')';

  insert into updatesql(createtime,exesql,olddata,opertype,iden) values (sysdate,d_sql,olddata,'Delete',:old.sid);

end ;




/

