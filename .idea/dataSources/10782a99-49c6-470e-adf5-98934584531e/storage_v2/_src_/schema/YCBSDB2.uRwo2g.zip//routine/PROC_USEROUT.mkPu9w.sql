CREATE procedure proc_UserOut
as
begin

declare
       --类型定义
       cursor c_job
       is
       select lasttime,sessionid
       from bs_loginsession
       where nvl(logoutflag,0)=0 ;
       --定义一个游标变量v_cinfo c_emp%ROWTYPE ，该类型为游标c_emp中的一行数据类型
       c_row c_job%rowtype;
begin
       for c_row in c_job loop

        if sysdate-1/24/6>c_row.lasttime
        --if sysdate>c_row.lasttime
          then
            update bs_loginsession set logout =sysdate ,logoutflag=1 where sessionid=c_row.sessionid;
          end if;
       end loop;
end;

end proc_UserOut;


/

