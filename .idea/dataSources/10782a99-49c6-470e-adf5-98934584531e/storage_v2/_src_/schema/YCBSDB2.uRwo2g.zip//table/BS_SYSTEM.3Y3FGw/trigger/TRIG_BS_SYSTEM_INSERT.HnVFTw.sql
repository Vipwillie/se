CREATE TRIGGER TRIG_BS_SYSTEM_INSERT
  BEFORE INSERT
  ON BS_SYSTEM
  FOR EACH ROW
  declare d_sql varchar2(4000);
         olddata varchar2(4000);
begin
d_sql := 'insert into bs_system(sid,sname,shortname,styp,homepage,orderno,url00,url01,url02,url03,url04,url05,url06,url07,url08,url09,url10,url11,url12,url13,url14,url15,url16,url17,url18,url19,url20,url21,url22,url23,url24,url25,url26,url27,url28,url29,url30)
values('''||:new.sid||''','''||:new.sname||''','''||:new.shortname||''','''||:new.styp||''','''||:new.homepage||''','''||:new.orderno||''','''||:new.url00||''','''||:new.url01||''','''||:new.url02||''','''||:new.url03||''','''||:new.url04||''','''||:new.url05||''','''||:new.url06||''','''||:new.url07||''','''||:new.url08||''','''||:new.url09||''','''||:new.url10||''','''||:new.url11||''','''||:new.url12||''','''||:new.url13||''','''||:new.url14||''','''||:new.url15||''','''||:new.url16||''','''||:new.url17||''','''||:new.url18||''','''||:new.url19||''','''||:new.url20||''','''||:new.url21||''','''||:new.url22||''','''||:new.url23||''','''||:new.url24||''','''||:new.url25||''','''||:new.url26||''','''||:new.url27||''','''||:new.url28||''','''||:new.url29||''','''||:new.url30||''')';

olddata:='delete from bs_system where sid ='''||:new.sid||'''';

  insert into updatesql(createtime,exesql,olddata,opertype,iden) values (sysdate,d_sql,olddata,'Insert',:new.sid);

end ;




/

