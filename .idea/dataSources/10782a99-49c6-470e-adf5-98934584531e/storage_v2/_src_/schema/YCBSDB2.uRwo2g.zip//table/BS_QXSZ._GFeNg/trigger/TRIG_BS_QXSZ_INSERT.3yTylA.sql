CREATE TRIGGER TRIG_BS_QXSZ_INSERT
  BEFORE INSERT
  ON BS_QXSZ
  FOR EACH ROW
  declare d_sql varchar2(4000);
         olddata varchar2(4000);
begin
d_sql :='insert into Bs_Qxsz(mkid,mid,mname,name,ur ,inurl,isuse,orderno,styp,parent,sid)
         values('''||:new.mkid||''','''||:new.mid||''','''||:new.mname||''','''||:new.name||''','''||:new.url ||''','''||:new.inurl||''','''||:new.isuse||''','''||:new.orderno||''','''||:new.styp||''','''||:new.parent||''','''||:new.sid||''')';


olddata:='delete from Bs_Qxsz where sid ='''||:new.sid||''' and mkid='''||:new.mkid||'''';

  insert into updatesql(createtime,exesql,olddata,opertype,iden) values (sysdate,d_sql,olddata,'Insert',:new.sid||'|'||:new.mkid);

end ;




/

