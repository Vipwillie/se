CREATE TRIGGER TRIG_BS_XTMK_UPDATE
  BEFORE UPDATE
  ON BS_XTMK
  FOR EACH ROW
  declare d_sql varchar2(4000);
         olddata varchar2(4000);
begin

d_sql:='update Bs_Xtmk set mname='''||:new.mname||''',styp='''||:new.styp||''',url00='''||:new.url00||''',url01='''||:new.url01||''',url02='''||:new.url02||''',url03='''||:new.url03||''',url04='''||:new.url04||''',url05='''||:new.url05||''',url06='''||:new.url06||''',url07='''||:new.url07||''',url08='''||:new.url08||''',url09='''||:new.url09||''',url10='''||:new.url10||''',ordby='''||:new.ordby||''',qxrole='''||:new.qxrole||''' where mid ='''||:new.mid||''' and sid='''||:new.sid||'''';
olddata:='update Bs_Xtmk set mname='''||:old.mname||''',styp='''||:old.styp||''',url00='''||:old.url00||''',url01='''||:old.url01||''',url02='''||:old.url02||''',url03='''||:old.url03||''',url04='''||:old.url04||''',url05='''||:old.url05||''',url06='''||:old.url06||''',url07='''||:old.url07||''',url08='''||:old.url08||''',url09='''||:old.url09||''',url10='''||:old.url10||''',ordby='''||:old.ordby||''',qxrole='''||:old.qxrole||''' where mid ='''||:old.mid||''' and sid='''||:old.sid||'''';

  insert into updatesql(createtime,exesql,olddata,opertype,iden) values (sysdate,d_sql,olddata,'Update',:new.sid||'|'||:new.mid);

end ;




/

