CREATE TRIGGER TRIG_BS_XTMK_INSERT
  BEFORE INSERT
  ON BS_XTMK
  FOR EACH ROW
  declare d_sql varchar2(4000);
         olddata varchar2(4000);
begin
d_sql :='insert into Bs_Xtmk(mid,mname,styp,url00,url01,url02,url03,url04,url05,url06,url07,url08,url09,url10,ordby,sid,qxrole)
         values('''||:new.mid||''','''||:new.mname||''','''||:new.styp||''','''||:new.url00||''','''||:new.url01||''','''||:new.url02||''','''||:new.url03||''','''||:new.url04||''','''||:new.url05||''','''||:new.url06||''','''||:new.url07||''','''||:new.url08||''','''||:new.url09||''','''||:new.url10||''','''||:new.ordby||''','''||:new.sid||''','''||:new.qxrole||''')';

olddata:='delete from Bs_Xtmk where sid ='''||:new.sid||''' and mid='''||:new.mid||'''';

  insert into updatesql(createtime,exesql,olddata,opertype,iden) values (sysdate,d_sql,olddata,'Insert',:new.sid||'|'||:new.mid);

end ;




/

