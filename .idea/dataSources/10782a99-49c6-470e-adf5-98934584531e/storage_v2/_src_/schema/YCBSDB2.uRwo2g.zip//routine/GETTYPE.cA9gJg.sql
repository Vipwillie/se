CREATE procedure         gettype(tname varchar2,cname varchar2)
/**
by anbob.com
discribe:get columns type fo table
param: tname is table name
param: cname is column
**/
is
v_ctype varchar2(30);
v_len number;
begin
select data_type,data_length into v_ctype,v_len from cols where table_name=upper(tname) and column_name =upper(cname);
dbms_output.put_line('info: this column  ['||cname||']of table ['||tname||'] type is >'||v_ctype||' ,lenth>'||v_len);
end;





/

