CREATE TRIGGER BS_STORE_MESSAGE_TRIGGER
  BEFORE INSERT
  ON BS_STORE_MESSAGE
  FOR EACH ROW
  begin
      select   shopstore_message_id_seq.nextval   into:new.MSG_ID from dual ;
end;







/

