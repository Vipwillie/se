CREATE TRIGGER TRIG_BS_QXSZ_UPDATE
  BEFORE UPDATE
  ON BS_QXSZ
  FOR EACH ROW
  declare d_sql varchar2(4000);
         olddata varchar2(4000);
begin

d_sql:='update Bs_Qxsz set mkid='''||:new.mkid||''',mid='''||:new.mid||''',mname='''||:new.mname||''',name='''||:new.name||''',url='''||:new.url||''',inurl='''||:new.inurl||''',isuse='''||:new.isuse||''',orderno='''||:new.orderno||''',styp='''||:new.styp||''',parent='''||:new.parent||''',sid='''||:new.sid||''' where sid ='''||:new.sid||''' and  mkid	=	'''||	:new.mkid	||'''';

olddata:='update Bs_Qxsz set mkid='''||:old.mkid||''',mid='''||:old.mid||''',mname='''||:old.mname||''',name='''||:old.name||''',url='''||:old.url||''',inurl='''||:old.inurl||''',isuse='''||:old.isuse||''',orderno='''||:old.orderno||''',styp='''||:old.styp||''',parent='''||:old.parent||''',sid='''||:old.sid||''' where sid ='''||:old.sid||''' and  mkid	=	'''||	:old.mkid	||'''';


  insert into updatesql(createtime,exesql,olddata,opertype,iden) values (sysdate,d_sql,olddata,'Update',:new.sid||'|'||:new.mkid);

end ;




/

