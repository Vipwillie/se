CREATE TRIGGER TRIG_BS_QXSZ_DELETE
  BEFORE DELETE
  ON BS_QXSZ
  FOR EACH ROW
  declare d_sql varchar2(4000);
         olddata varchar2(4000);
begin

         d_sql:='delete from Bs_Qxsz where sid ='''||:old.sid||''' and mkid='''||:old.mkid||'''';

         olddata :='insert into Bs_Qxsz(mkid,mid,mname,name,ur ,inurl,isuse,orderno,styp,parent,sid)
         values('''||:old.mkid||''','''||:old.mid||''','''||:old.mname||''','''||:old.name||''','''||:old.url ||''','''||:old.inurl||''','''||:old.isuse||''','''||:old.orderno||''','''||:old.styp||''','''||:old.parent||''','''||:old.sid||''')';

         insert into updatesql(createtime,exesql,olddata,opertype,iden) values (sysdate,d_sql,olddata,'Delete',:old.sid||'|'||:old.mkid);
end ;




/

