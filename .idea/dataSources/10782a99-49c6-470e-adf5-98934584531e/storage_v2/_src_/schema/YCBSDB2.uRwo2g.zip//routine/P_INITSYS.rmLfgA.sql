CREATE procedure         P_INITSYS(initType in int,ref_msg out varchar2) is
/**********************************************************
 * procedure : P_INITSYS
 * dec       : 系统初始化
 * author    : flotage
 * create    : 2012.09.20
 * param     : initType 1 - 业务初始化 2 - 系统上线初始化
 **********************************************************/
 licount int;
 strsql varchar2(500);
begin
  if (initType<>1 and initType<>2) then
     ref_msg:='参数错误：initType值必须是1（业务初始化）或者2（系统上线初始化）。';
     return;
  end if;

  -- 查看是否存在未设置的表
  select count(0) into licount from tab
  where tname not in (
        select tname from sys_init
  ) and tname not like 'BIN$%' and tabtype='TABLE';

  if nvl(licount,0)>0 then
     ref_msg:='存在未设置规则的新表，请先设置删除规则后再操作1。';
     return;
  end if;

  licount:=0;
  select count(0) into licount from sys_init where nvl(flag,9999)=9999;
  if nvl(licount,0)>0 then
     ref_msg:='存在未设置规则的新表，请先设置删除规则后再操作2。';
     return;
  end if;

  declare cursor c_deltab is
    select tname,flag from sys_init where flag<>0;

  v_deltab c_deltab%rowtype;
  begin
     open c_deltab;
     loop
         fetch c_deltab into v_deltab;
         exit when c_deltab%notfound;
         strsql:='';

         -- 组织删除规则
         if (initType=1 and v_deltab.flag=2) then
            strsql:='-'; -- 不删除
         else
            strsql:='delete '||v_deltab.tname;
         end if;
         if (nvl(strsql,'-')<>'-') then
            execute immediate strsql;
         end if;
      end loop;
      close c_deltab;
  end;

  ref_msg:='success';
end P_INITSYS;





/

