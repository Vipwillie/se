CREATE TRIGGER TRIG_BS_QXMX_INSERT
  BEFORE INSERT
  ON BS_QXMX
  FOR EACH ROW
  declare d_sql varchar2(4000);
         olddata varchar2(4000);
begin
d_sql :='insert into Bs_qxmx(pkid,mkid,action,method,accesstag,remark,styp,sid)
         values('''||:new.pkid||''','''||:new.mkid||''','''||:new.action||''','''||:new.method||''','''||:new.accesstag||''','''||:new.remark||''','''||:new.styp||''','''||:new.sid||''')';


olddata:='delete from Bs_qxmx where pkid ='''||:new.pkid||'''';

  insert into updatesql(createtime,exesql,olddata,opertype,iden) values (sysdate,d_sql,olddata,'Insert',:new.pkid);

end ;




/

