CREATE TRIGGER TRIG_BS_SYSTEM_UPDATE
  BEFORE UPDATE
  ON BS_SYSTEM
  FOR EACH ROW
  declare d_sql varchar2(4000);
         olddata varchar2(4000);
begin

d_sql:='update bs_system set sname='''||:new.sname||''',shortname='''||:new.shortname||''',styp='''||:new.styp||''',homepage='''||:new.homepage||''',orderno='''||:new.orderno||''',url00='''||:new.url00||''',url01='''||:new.url01||''',url02='''||:new.url02||''',url03='''||:new.url03||''',url04='''||:new.url04||''',url05='''||:new.url05||''',url06='''||:new.url06||''',url07='''||:new.url07||''',url08='''||:new.url08||''',url09='''||:new.url09||''',url10='''||:new.url10||''',url11='''||:new.url11||''',url12='''||:new.url12||''',url13='''||:new.url13||''',url14='''||:new.url14||''',url15='''||:new.url15||''',url16='''||:new.url16||''',url17='''||:new.url17||''',url18='''||:new.url18||''',url19='''||:new.url19||''',url20='''||:new.url20||''',url21='''||:new.url21||''',url22='''||:new.url22||''',url23='''||:new.url23||''',url24='''||:new.url24||''',url25='''||:new.url25||''',url26='''||:new.url26||''',url27='''||:new.url27||''',url28='''||:new.url28||''',url29='''||:new.url29||''',url30='''||:new.url30||''' where sid ='''||:new.sid||'''';
olddata :='update bs_system set sname='''||:old.sname||''',shortname='''||:old.shortname||''',styp='''||:old.styp||''',homepage='''||:old.homepage||''',orderno='''||:old.orderno||''',url00='''||:old.url00||''',url01='''||:old.url01||''',url02='''||:old.url02||''',url03='''||:old.url03||''',url04='''||:old.url04||''',url05='''||:old.url05||''',url06='''||:old.url06||''',url07='''||:old.url07||''',url08='''||:old.url08||''',url09='''||:old.url09||''',url10='''||:old.url10||''',url11='''||:old.url11||''',url12='''||:old.url12||''',url13='''||:old.url13||''',url14='''||:old.url14||''',url15='''||:old.url15||''',url16='''||:old.url16||''',url17='''||:old.url17||''',url18='''||:old.url18||''',url19='''||:old.url19||''',url20='''||:old.url20||''',url21='''||:old.url21||''',url22='''||:old.url22||''',url23='''||:old.url23||''',url24='''||:old.url24||''',url25='''||:old.url25||''',url26='''||:old.url26||''',url27='''||:old.url27||''',url28='''||:old.url28||''',url29='''||:old.url29||''',url30='''||:old.url30||''' where sid ='''||:old.sid||'''';

  insert into updatesql(createtime,exesql,olddata,opertype,iden) values (sysdate,d_sql,olddata,'Update',:new.sid);

end ;




/

